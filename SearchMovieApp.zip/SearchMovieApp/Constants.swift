//
//  Constants.swift
//  SearchMovieApp
//
//  Created by t2023-m0096 on 2023/08/16.
//

import Foundation

struct Constants {
    static let API_Key = "13f5210533026fe56ff773bbc5297ba9"
    static let baseURL = "https://api.themoviedb.org/3/movie/popular"
    
    private init() {}
}
