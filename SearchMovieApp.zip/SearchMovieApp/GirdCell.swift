//
//  GirdCell.swift
//  SearchMovieApp
//
//  Created by t2023-m0096 on 2023/08/14.
//

import UIKit

class GirdCell: UICollectionViewCell {
    
    @IBOutlet weak var rating: UILabel!
    @IBOutlet weak var title: UILabel!
    @IBOutlet weak var thumbnail: UIImageView!
}
